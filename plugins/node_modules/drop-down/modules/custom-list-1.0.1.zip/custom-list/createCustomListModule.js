import { shortcut } from './sidebar/index.js';

// ************************************************************************** 普通函数

/**
 * 点击自定义列表按钮事件
 */
function onBtnEvent(  g_$target, $target ) {
    
  let $btn = $target.closest('.drop-down__button');
  // 点击按钮事件
  if ($btn.length) {
      g_$target.toggleClass('drop-down__selected');
      if(g_$target.hasClass('drop-down__selected')){
      if( $('.drop-down__selected').not(g_$target).length ) {
          $('.drop-down__selected').not(g_$target).removeClass('drop-down__selected');
          g_$target.trigger( 'close' );
      } else {
          g_$target.trigger( 'open' );
      }
      } else {
          g_$target.trigger( 'close' );
      }
  }
}

/**
* 渲染全选按钮
*/
function renderCheckAll() {
  let html = '';
  html += '<div class="check-all-container">';
  html += '<input type="checkbox" lay-ignore class="tree-check-all"/>全选';
  html += '</div>';
  return html;
}

/**
* 修正全选状态
*/
function correctionCheckAllState( $selectAnim ) {
  let $CheckAll = $selectAnim.find( '.tree-check-all' );
  let $checkbox = $selectAnim.find( '.tree-check' );
  let $checkboxUsableList = $checkbox.not( '[disabled]' );
  let $checkboxCheckedList = $checkboxUsableList.filter( '[checked=checked]' );
  let state;
  // 全选
  if(
    // 选中数据数量不能与0，不包括禁用选项
    0 !== $checkboxCheckedList.length 
    // 选中数据数量等于选项数量（不包括禁用选项）
    && $checkboxUsableList.length === $checkboxCheckedList.length 
  ) {
    state = 'checked';
      $CheckAll.attr('checked','checked').prop('checked',true)
          .addClass( 'tree-check-all--selected' );
  }
  // 半选状态
  else if(
    // 选中数据数量不能与0，不包括禁用选项
    0 !== $checkboxCheckedList.length
    // 选中数据数量不等于选项数量（不包括禁用选项）
    && $checkboxUsableList.length !== $checkboxCheckedList.length
  ) {
    state = 'indeterminate';
    $CheckAll.removeAttr('checked').prop('checked',false)
      .removeClass( 'tree-check-all--selected' )
      .addClass( 'tree-check-all--indeterminate' );
  }
  // 未选
  else {
    state = 'unchecked';
      $CheckAll.removeAttr('checked').prop('checked',false)
          .removeClass( 'tree-check-all--indeterminate' )
          .removeClass( 'tree-check-all--selected' );
  }
  return state;
}


// -----------------------------------------------------------------------------

// 自定义列表组件对象
function createCustomListModule( $target, option, $origin ) {
  // 默认配置
  let g_default_options = {
      children: 'children',// 子数据对应的属性名
      usingCheckAll: false,// 使用全选
      checked: [],// 默认选中
      immediately: true, // 即时响应
      shortcuts: [], // 快捷选项
      disabledList: [], // 被禁用的数组
      min: 1, // 最小选中的数量
      triggerIndex: null
  };
  this.g_default_options = Object.assign( g_default_options, option );
  // 原始元素
  this.g_$origin =  $origin;
  // 主渲染元素DOM
  this.g_$target = $target;
  // 渲染的下拉内容主体
  this.g_$selectAnim = null;
  // 扁平化后的数据
  this.g_flatteningData = [];
  // 最低级子节点等级
  this.g_lowestLevel = 1;
  // 操作缓存：用于记录取消操作之前的操作
  this.operationCache = [];
}

// 初始化方法
createCustomListModule.prototype.init = function() {
   // 渲染下拉内容
   this.renderDOM(this.g_$target, this.g_default_options);
   // 绑定事件
   this.bindEvent();
};

// 渲染下拉内容
createCustomListModule.prototype.renderDOM = function renderDOM() {
  let contentHtml = '<div class="drop-down__anim__content">';
  // 扁平化数据
  this.flattening( this.g_default_options.data, 1 );
      // 渲染侧边栏
  let sidebarHtml = this.renderSidebar();
  if( sidebarHtml ) {
      contentHtml += sidebarHtml;
      contentHtml += '<span class="drop-down__partition-line"></span>';
  }
  // 渲染节点树
  contentHtml += this.renderTree();
  contentHtml += '</div>';
  // 即刻 控制按钮
  let renderImmediatelyControlHtml = this.renderImmediatelyControl();
  if( renderImmediatelyControlHtml ) {
      contentHtml += renderImmediatelyControlHtml;
  }
  this.g_$selectAnim = this.g_$target.find('.drop-down__anim').html( contentHtml );
};

// 扁平化数据,并设置等级
createCustomListModule.prototype.flattening = function flattening(data, level) {
  for (let i = 0, item; item = data[i++];) {
      item.level = level;
      this.g_lowestLevel = Math.max( this.g_lowestLevel,level );
      this.g_flatteningData.push( item );
      if ( item[ this.g_default_options.children ] ) {
        this.flattening( item[ this.g_default_options.children ], level + 1);
      }
  }
};

// 渲染侧边栏
createCustomListModule.prototype.renderSidebar =  function renderSidebar() {
  let contentHtml = '';
  // 快捷项
  let shortcutHtml;
  if( this.g_default_options.shortcuts && this.g_default_options.shortcuts.length ) {
      shortcutHtml = shortcut( this.g_default_options );
  }
  if( shortcutHtml ) {
      contentHtml += '<div class="drop-down__sidebar">';
      contentHtml += '<h5 class="title">快捷纬度</h5>';
      contentHtml += shortcutHtml;
      contentHtml += '</div>';
  }
  return contentHtml;
};

// 渲染树节点
createCustomListModule.prototype.renderTree = function renderTree() {
  let html = '';
  // 节点数据
  let data = this.g_flatteningData;
  let g_default_options = this.g_default_options;

  html += '<div class="tree-container">';

  if( g_default_options.shortcuts.length ) {
      html += '<h5 class="title">自定义纬度</h5>';
  }
      
  // 全选
  if( g_default_options.usingCheckAll ) {
      html += renderCheckAll();
  }

  html += '<dl>';
  let tier = [];
  for (let i = 0, item; item = data[i];i++) {
      let isDisbaled = -1 !== g_default_options.disabledList.indexOf( item[g_default_options.unique] );
      let isChecked = -1===g_default_options.checked.indexOf(item[g_default_options.unique]);

      if(!tier[tier.length - 1] || tier[tier.length - 1].level < item.level) {
        tier.push(item)
      } else if(tier[tier.length - 1].level > item.level) {
        let lastLevel = tier[tier.length - 1].level
        while( lastLevel > item.level) {
          tier.pop()
          lastLevel = tier[tier.length - 1].level
        }
      }

      html += `<dd
        class="level-${item.level} ${isChecked?'':'tree-check-selected'}  ${ isDisbaled ? 'tree-check--disabled':'' }"
        data-level="${item.level}"
        data-leaf="${data[i + 1] ? data[i + 1].level <= item.level : true}"
        style="padding-left: ${20 * item.level - 1}px"
      >`;
      if( isDisbaled ) {
          html += `<input disabled type="checkbox" lay-ignore ${isChecked?'':'checked'} class="tree-check" value="${item[g_default_options.unique]}"/>`;
      } else {
          html += `<input type="checkbox" lay-ignore ${isChecked?'':'checked'} class="tree-check" value="${item[g_default_options.unique]}"/>`;
      }
      html += `<span class="tree-name">${item[g_default_options.display]}</span>`;
      html += '</dd>';
  }
  html += '</dl>';



  html += '</div>';
  return html;
};

// 即刻 控制按钮
createCustomListModule.prototype.renderImmediatelyControl = function renderImmediatelyControl() {
  let html = '';
if( !this.g_default_options.immediately ) {
    html += '<div class="control">';
    html += '<button type="button" class="cancel">取消</button>';
    html += '<button type="button" class="confirm">应用</button>';
    html += '</div>';
}
return html;
};

// 绑定事件
createCustomListModule.prototype.bindEvent = function bindEvent() {
  let that = this;

  that.g_$target.on('click', function(e) {
      let $t = $(e.target);
      // 点击自定义列表按钮事件
      onBtnEvent( that.g_$target, $t );
      // 取消确定按钮事件
      that.onCancelConfirmEvent( $t );
      // checkbox事件
      that.onCheckboxEvent( $t, e );
      // 快捷选项点击事件
      that.onShortcutClickEvent( $t );
      // 点击全选按钮
      that.onClickCheckAll( $t );
  });


  that.g_$target.on( 'open', function() {
      
      if( !that.g_default_options.immediately ) {
          that.operationCache = that.getCheckedValues();
      }
  });

  that.g_$target.on('close', function() {
      
      if( !that.g_default_options.immediately ) {
          let $checkbox = that.g_$selectAnim.find( 'dd' ).not( '.tree-check--disabled' ).find( '.tree-check' );
          if( !that.operationCache.length )return;

          for( let i = 0, len = $checkbox.length; i < len; i++ ) {
              const $element = $( $checkbox[ i ] );
              let value = $element[ 0 ].value;
              if( -1 !== that.operationCache.indexOf( value ) ) {
                that.checkedNode($element.closest('dd'), that.g_default_options)
              } else {
                that.cancleNode($element.closest('dd'), that.g_default_options)
              }
          }
          // 修复默认数据设置
          that.repairDefault()
          // 清空操作缓存
          that.operationCache = [];

          if( that.g_default_options.usingCheckAll ) {
              // 修正全选状态
              correctionCheckAllState( that.g_$selectAnim );
          }
          
      }
  });
  // 修复默认数据设置
  that.repairDefault();
};

// 取消确定按钮事件
createCustomListModule.prototype.onCancelConfirmEvent =  function onCancelConfirmEvent( $target ) {
  // 取消按钮
  let $cancel = $target.closest('.cancel');
  // 确定按钮
  let $confirm = $target.closest('.confirm');
  if( $cancel.length ) {
      this.g_$target.toggleClass('drop-down__selected');
      this.g_$target.trigger( 'close' );
  }else if( $confirm.length ) {
      this.g_$target.toggleClass('drop-down__selected');
      this.triggerChange( null )
      this.operationCache = [];
      this.g_$target.trigger( 'close' );
  }
};


// 发送事件
createCustomListModule.prototype.triggerChange =  function triggerChange(currentVal){
  let that = this;

  if(null !== that.triggerIndex) {
    clearTimeout(that.triggerIndex)
  }

  that.triggerIndex = setTimeout(function() {
    that.triggerIndex = null
    let fire  = {};
    if(that.warning) {
      fire.warning = that.warning;
      that.warning = null;
    }
    fire.data = currentVal;
    fire.list = that.getCheckedValues();
    that.g_$origin.trigger('change',fire);
  }, 200)

};

// 获取所有的选中值
createCustomListModule.prototype.getCheckedValues = function getCheckedValues() {
  // 获取所有选中状态的checkbox
let $brother = this.g_$selectAnim.find('.tree-check-selected');
// 获取
let checkedList = [];
for (let i = 0, item; item = $brother[i++];) {
  checkedList.push($(item).find('input').val());
}
return checkedList;
};

// 修复默认数据设置
createCustomListModule.prototype.repairDefault = function repairDefault(){
    let that = this;
  for (let i = 2; i <= that.g_lowestLevel; i++) {
    // 计算父元素状态(是否选中)
    that.g_$selectAnim.find('.tree-check-selected.level-'+i).each(function(i,item){
      that.calculationParentState($(item))
    });
  }
};

// 多选框事件
createCustomListModule.prototype.onCheckboxEvent =  function onCheckboxEvent( $target, e ) {
  let $checkbox = $target.closest('.tree-check[type="checkbox"]');
  let $dd = $target.closest('dd');
  // 点击checkbox事件(主动触发采用自然算法)
  if ( $checkbox.length ){
      // 设置checkbox状态
      if ($checkbox.prop('checked')) {
        // 选中节点
        this.checkedNode($dd);
      } else {
        this.cancleNode($dd);
      }
      // 修正全选状态
      if( this.g_default_options.usingCheckAll ) {
        correctionCheckAllState( this.g_$selectAnim );
      }
      e.stopPropagation();
  } else if( $dd.length ) {
      $dd.find('input[type="checkbox"]').trigger('click');
  }
};

// checkbox事件
/**
 * checkbox事件
 * @param {String} name 算法名称
 * @param {Object} $checkbox 当前点击的checkbox
 * @param {Boolean} state 点击的状态(不设置则按照节点状态判断)
 */
createCustomListModule.prototype.checkboxEvent = function checkboxEvent(name,$checkbox,state) {
  let $dd = $checkbox.closest('dd');
  // 子节点关系(触发点击子节点事件)
  this.childRelationship( $dd, name==='natural' ? $dd.data('level') : 0);
};


// 方法 
// 全选
createCustomListModule.prototype.checkAll = function checkAll() {
  this.g_$selectAnim.find( 'dd' ).not( '.tree-check--disabled' ).addClass(' tree-check-selected')
      .find( '.tree-check' ).attr('checked','checked').prop('checked',true);
  // 即时响应
  if( this.g_default_options.immediately ) {
      this.triggerChange( null);
  }
};

// 取消全选
createCustomListModule.prototype.deselectAll = function deselectAll() {
    
  this.g_$selectAnim.find( 'dd' ).not( '.tree-check--disabled' ).removeClass(' tree-check-selected').removeClass(' tree-check-indeterminate')
      .find( '.tree-check' ).removeAttr('checked').prop('checked',false);
  // 当有没有选中项时（包括选中禁用项）
  if( !this.g_$selectAnim.find( '.tree-check-selected' ).length ) {
      // 保留一项
      this.keepAItem();
  }
};

// 保留一项
createCustomListModule.prototype.keepAItem = function keepAItem() {
  let firstChild = this.getFirstChild( this.g_default_options.data );
  this.g_$selectAnim.find( '.tree-check' ).filter( '[value='+ firstChild[ this.g_default_options.unique ] +']' ).click();
  this.warning = '请至少保留一列！';
};

// 获取第一个可用的节点
createCustomListModule.prototype.getFirstChild = function getFirstChild( data ) {
  for( let i = 0, len = data.length; i < len; i++ ) {
     const element = data[ i ];
     // 不是被禁用的节点
     if( -1 === this.g_default_options.disabledList.indexOf( element[ this.g_default_options.unique ] ) ) {
          let children = element[ this.g_default_options.children ];
          if( children && children.length ) {
              return this.getFirstChild( children );
          } else {
              return element;
          }
     }
  }
};


// 快捷方式点击事件
/**
 * 快捷方式点击事件
 * @param { Element } $target 
 * @returns 
 */
createCustomListModule.prototype.onShortcutClickEvent =  function onShortcutClickEvent( $target ) {
  let $shortcut = $target.closest('.shortcut-item');
  if ($shortcut.length) {
      this.g_$selectAnim.find( '.shortcut-item' ).removeClass( 'shortcut-item--active' );
      let attrValue = $shortcut.addClass( 'shortcut-item--active' ).attr( 'attr-value' );
      let values = attrValue.split( ',' );
      let $treeChecksAll = this.g_$selectAnim.find( '.tree-check' );
      let rules = '';
      for( let i = 0, len = values.length; i < len; i++ ) {
         rules += `[value=${ values[ i ] }]`;
          if( i + 1 < len ) {
              rules += ',';
          }
      }
      // 清除所有选中
      $treeChecksAll.prop( 'checked', false ).closest('dd[class^=level-]').removeClass('tree-check-selected');
      // 选中快捷选项对应的checkbox
      $treeChecksAll.filter( rules ).click();
      this.g_$target.toggleClass('drop-down__selected');
      this.triggerChange( null );
      this.operationCache = [];
      this.g_$target.trigger( 'close' );
  }
};
// 点击全选事件
createCustomListModule.prototype.onClickCheckAll = function onClickCheckAll( $target ) {
  let $treeCheckAll = $target.closest('.tree-check-all');

  if ( $treeCheckAll.length ) {
      if( $treeCheckAll.prop( 'checked' ) ) {
          $treeCheckAll.attr( 'checked', 'checked' ).addClass('tree-check-all--selected');
          this.checkAll();
      } else {
          $treeCheckAll.removeAttr('checked').removeClass('tree-check-all--selected');
          this.deselectAll();
      }

  }
};

/**
 * 选中节点
 */
createCustomListModule.prototype.checkedNode = function checkedNode($dd, direction){
  $dd.removeClass('tree-check-indeterminate')
      .addClass('tree-check-selected')
          .find('input[type="checkbox"]')
          .attr('checked','checked')
          .prop('checked',true)
  this.chainReaction($dd, direction)
}

/**
* 设置半选节点
*/
createCustomListModule.prototype.indeterminateNode = function indeterminateNode($dd, direction){
  $dd.removeClass('tree-check-selected')
      .addClass('tree-check-indeterminate')
        .find('input[type="checkbox"]')
          .removeAttr('checked')
          .prop('checked',false);
  this.chainReaction($dd, direction)
}

function findParent($dd) {
  let list = [];
  let level = $dd.data('level')
  let $prev = $dd.prev();

  while($prev.length) {
    if($prev.data('level') < level) {
      list.push($prev[0])
      level = $prev.data('level')
    }
    $prev = $prev.prev();
  }
  return list
}

/**
* 取消节点
*/
createCustomListModule.prototype.cancleNode = function cancleNode($dd, direction){
  for(let i = 0, len = $dd.length; i < len; i++) {
    let isLast = this.isLastChecked($dd)
    // 需要回滚的叶子元素
    if( isLast) {
      // 选中节点(最后一个节点,状态回滚)
      this.checkedNode($($dd[i]), 'parent');
      this.warning = '请至少保留一列！';
      this.triggerChange( $($dd[i]).find('input[type="checkbox"]').val())
    }
     else {
      $($dd[i]).removeClass('tree-check-selected')
                .removeClass('tree-check-indeterminate')
                  .find('input[type="checkbox"]')
                  .removeAttr('checked')
                  .prop('checked',false);
      this.chainReaction($($dd[i]), direction)
    }
  }
}


createCustomListModule.prototype.isLastChecked = function isLastChecked($dd){
  let level = $dd.data('level');
  let ancestor = [$dd[0], ...findParent($dd)];
  let islast = true
  for( let i = level;i >= 1; i-- ) {
    // 祖先/同辈选中
    let selected = this.g_$selectAnim.find(`dd.tree-check-selected.level-${i}`).filter(function() {
      // 不在祖先链上
      return -1 === ancestor.indexOf(this)
    })
    if(selected.length){
      islast = false
      break
    }
    // 祖先/同辈半选
    let indeterminate = this.g_$selectAnim.find(`dd.tree-check-indeterminate.level-${i}`).filter(function() {
      // 不在祖先链上
      return -1 === ancestor.indexOf(this)
    })
    if(indeterminate.length) {
      islast = false
      break
    }
  }
  return islast
};




/**
 * 连锁反应
 */
createCustomListModule.prototype.chainReaction = function chainReaction($dd, direction) {
  if('parent' === direction) {
    this.calculationParentState($dd)
  } else if('child' === direction) {
    this.childRelationship($dd)
  } else {
    this.childRelationship($dd)
    this.calculationParentState($dd)
  }
}

/**
 * 子元素状态
 * isChain 是否是连锁反应触发
 */
createCustomListModule.prototype.childRelationship = function childRelationship($dd) {
   let that = this;
  // 记录点击过的节点
  let cache = [];
  // 点击的父节点的数据
  let parentVal = null;
  // 顶级等级
  let topLevel = 1;
  
  /**
   * @param {Object} $dd 被检查节点
   * @param {Number} level 等级
   * 
   */
  function fn($dd,level){
    // 选中状态
    let state = $dd.hasClass('tree-check-selected');
    // 点击的checkbox
    let $checkbox = $dd.find('input[type="checkbox"]');

    // 第一次设置等级(点击父节点的时候需要存储的数据)
    if(level){
      topLevel = level,
      parentVal = $checkbox.val();
    }

    // 存储变化过的节点数据
    cache.push($checkbox.val());

    // 点击节点的下一个节点等级
    let breakd = false;
    let $nextNode = $dd.nextAll('dd').not('.tree-check--disabled').filter(function() {
      if(topLevel >= $(this).data('level')) {
        breakd = true
      }
      return breakd ? false : true
    });

    // 判断是不是子节点
    if( $nextNode.length ){
      if(state){
        // 选中节点
        that.checkedNode($nextNode, 'child');
      }else{
        that.cancleNode($nextNode, 'child')
      }
    }else{
      // 同级节点(结束递归点击)
      if( that.g_default_options.immediately ) {
        that.triggerChange(parentVal);
      }
      // 记录点击过的节点
      cache = [];
      // 点击的父节点的数据
      parentVal = null;
      // 顶级等级
      topLevel = 1;
    }
  }

  fn($dd, $dd.data('level') || 0)
};


/**
 * 考虑父元素状态
 * @param {Object} $node 被检查节点
 */
createCustomListModule.prototype.calculationParentState = function calculationParentState($node, $parent) {
  // 是否全部选中
  let checkArr = [];

  if( $node.find('input[type="checkbox"]').prop('checked') ) {
    checkArr = [true]
  } else {
    checkArr = [$node.hasClass('tree-check-indeterminate')? 'indeterminate' : false]
  }

  // 设置节点的默认父节点
  if(!$parent) {
    let level = $node.data('level')-1;
    let all = $node.prevAll('.level-'+level);
    if(all.length) {
      $parent = $(all[0])
    } else {
      return
    }
  }
  
  // 查找
  function _find($node, mode){
    let level = $node.data('level');
    let $other = $node[mode]();
    while($other.length && $($other[0]).data('level') >= level) {
      let $current = $($other[0]).find('input[type="checkbox"]').not( '[disabled]' )
      if($($other[0]).data('level') === level && $current.length) {
        let checked = $current.prop('checked')
        if(!checked) {
          checkArr.push($other.hasClass('tree-check-indeterminate')? 'indeterminate' : false);
        } else {
          checkArr.push(checked);
        }
        
      }
      $other = $($other[0])[mode]()
    }
  }
  _find($node, 'prev');
  _find($node, 'next');
  
  // 全部是true,并且原父元素状态不是true
  if( -1 === checkArr.indexOf(false) && -1 === checkArr.indexOf('indeterminate') && !$parent.hasClass('tree-check-selected')){
    this.checkedNode($parent, 'parent')
  } 
  // 半选状态
  else if (-1 !== checkArr.indexOf(true) && !$parent.hasClass('tree-check-indeterminate') || -1 !== checkArr.indexOf('indeterminate')) {
    this.indeterminateNode($parent, 'parent')
  } 
  // 取消状态要都取消
  else if(-1 === checkArr.indexOf(true)){
    this.cancleNode($parent, 'parent')
  }
}

export default createCustomListModule