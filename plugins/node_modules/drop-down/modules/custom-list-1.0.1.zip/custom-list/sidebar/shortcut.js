// 快捷选项
let g_default_options;

// 渲染函数
function render( options ) {
    g_default_options = options;
    let contentHtml = '';
    for( let i = 0, len = g_default_options.shortcuts.length; i < len; i++ ) {
       const element = g_default_options.shortcuts[ i ];
       contentHtml += `<span class="shortcut-item" attr-value="${element[ g_default_options.unique ]}" title="${ element[ g_default_options.display ] }">${ element[ g_default_options.display ] }</span>`;
    }

    if( contentHtml ) {
        contentHtml = '<div class="shortcut-warp">' + contentHtml + '</div>';
    }

    return contentHtml;
}

export default render;