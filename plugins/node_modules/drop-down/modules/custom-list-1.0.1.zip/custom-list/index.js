
// 自定义列表对象
import createCustomListModule from './createCustomListModule.js'

export default {
    render($target, option, $origin) {
        let customListModule = new createCustomListModule( $target, option, $origin );
        customListModule.init();
    }
}
